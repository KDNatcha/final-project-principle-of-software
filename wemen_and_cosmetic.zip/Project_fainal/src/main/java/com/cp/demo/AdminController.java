package com.cp.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AdminController {
	
	@Autowired
	AdminRepository adminrepository;
	@GetMapping("/registration")
	public String getRePage() {
		return "register";
	}
	@PostMapping("/registration")
	public String saveSeller_Admin(@ModelAttribute Seller_Admid seller_admin,Model model) 
	{
		adminrepository.save(seller_admin);
		model.addAttribute("messge","Submitted Successfull");
		
		return "register";
	}
	
	
	

}
