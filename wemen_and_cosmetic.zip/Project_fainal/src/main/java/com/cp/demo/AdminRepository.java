package com.cp.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface  AdminRepository extends JpaRepository <Seller_Admid,Integer>{
	

}
