package com.cp.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectFainalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectFainalApplication.class, args);
	}

}
